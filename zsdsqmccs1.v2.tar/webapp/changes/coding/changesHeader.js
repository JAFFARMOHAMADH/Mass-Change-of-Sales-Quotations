/***
@controller Name:cus.sd.sq.mccs1.ext.salesquotationdetails.SalesQuotationDetails,
*@viewId:cus.sd.sq.mccs1::sap.suite.ui.generic.template.Canvas.view.Canvas::navigateToHeaderObjectPage--template::ImplementingComponentContent---idSalesQuotationDetails
*/
/*!
 * OpenUI5
 * (c) Copyright 2009-2022 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */

sap.ui.define([
	'sap/ui/core/mvc/ControllerExtension',
	'sap/ui/model/json/JSONModel',
	'sap/m/MessageBox',
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator'
	// ,'sap/ui/core/mvc/OverrideExecution'
],
	function (
		ControllerExtension,
		JSONModel,
		MessageBox,
		Filter,
		FilterOperator
		// ,OverrideExecution
	) {
		"use strict";
		return ControllerExtension.extend("customer.zsdsqmccs1.v2.changesHeader", {
			// metadata: {
			// 	// extension can declare the public methods
			// 	// in general methods that start with "_" are private
			// 	methods: {
			// 		publicMethod: {
			// 			public: true /*default*/ ,
			// 			final: false /*default*/ ,
			// 			overrideExecution: OverrideExecution.Instead /*default*/
			// 		},
			// 		finalPublicMethod: {
			// 			final: true
			// 		},
			// 		onMyHook: {
			// 			public: true /*default*/ ,
			// 			final: false /*default*/ ,
			// 			overrideExecution: OverrideExecution.After
			// 		},
			// 		couldBePrivate: {
			// 			public: false
			// 		}
			// 	}
			// },

			// // adding a private method, only accessible from this controller extension
			// _privateMethod: function() {},
			// // adding a public method, might be called from or overridden by other controller extensions as well
			// publicMethod: function() {},
			// // adding final public method, might be called from, but not overridden by other controller extensions as well
			// finalPublicMethod: function() {},
			// // adding a hook method, might be called by or overridden from other controller extensions
			// // override these method does not replace the implementation, but executes after the original method
			// onMyHook: function() {},
			// // method public per default, but made private via metadata
			// couldBePrivate: function() {},
			// // this section allows to extend lifecycle hooks or override public methods of the base controller
			override: {
				// 	/**
				// 	 * Called when a controller is instantiated and its View controls (if available) are already created.
				// 	 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
				// 	 * @memberOf customer.zsdsqmccs1.v2.changesHeader
				// 	 */
				onInit: function () {
					let oChangeData = {
						deliveryDate: "",
						deliveryDateValid: true,
						validFrom: "",
						validFromValid: true,
						validTo: "",
						validToValid: true,
					};

					let oIconData = {
						validFrom: false,
						validTo: false,
						check: false
					};

					let oLocalData = {
						"basicData": {
							"deliveryDate": {
								"visible": true,
								"enabled": true,
								"currentOperation": ""
							},
							"validFrom": {
								"visible": true,
								"enabled": true,
								"currentOperation": ""
							},
							"validTo": {
								"visible": true,
								"enabled": true,
								"currentOperation": ""
							},
							"material": {
								"visible": true,
								"enabled": true,
								"currentOperation": ""
							},
							"plant": {
								"visible": true,
								"enabled": true,
								"currentOperation": ""
							},
							"price": {
								"visible": true,
								"enabled": true,
								"currentOperation": ""
							},
							"quantity": {
								"visible": true,
								"enabled": true,
								"currentOperation": ""
							},
							"volume": {
								"visible": true,
								"enabled": true,
								"currentOperation": ""
							}
						},
						"page": "header"
					};

					var oLocalModel = new JSONModel(),
						oChangeModel = new JSONModel(),
						oIconItemModel = new JSONModel();

					// oLocalModel.loadData("../webapp/changes/localData.json", false);

					// oLocalModel.attachRequestCompleted(function (oEvt) {
					// 	let oData = oEvt.getSource().getData();
					// 	oData.page = "header";
					// 	this.getView().getModel("localModel").setData(oEvt.getSource().getData());
					// }.bind(this));

					oLocalModel.setData(oLocalData);
					this.getView().setModel(oLocalModel, "localModel");

					oChangeModel.setData(oChangeData);
					this.getView().setModel(oChangeModel, "changeModel");

					oIconItemModel.setData(oIconData);
					this.getView().setModel(oIconItemModel, "localIconModel");
				},

				// 	/**
				// 	 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
				// 	 * (NOT before the first rendering! onInit() is used for that one!).
				// 	 * @memberOf customer.zsdsqmccs1.v2.changesHeader
				// 	 */
				// 	onBeforeRendering: function() {
				// 	},

				// 	/**
				// 	 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
				// 	 * This hook is the same one that SAPUI5 controls get after being rendered.
				// 	 * @memberOf customer.zsdsqmccs1.v2.changesHeader
				// 	 */
				onAfterRendering: function () {
					// Hiding the existing standard fields
					this.getView().byId("cus.sd.sq.mccs1::sap.suite.ui.generic.template.Canvas.view.Canvas::navigateToHeaderObjectPage--template::ImplementingComponentContent---idSalesQuotationDetails--idSQDetailsBasicDataSubSection").getBlocks()[0].setVisible(false);

					// Hiding Terms and Conditions block
					this.getView().byId("cus.sd.sq.mccs1::sap.suite.ui.generic.template.Canvas.view.Canvas::navigateToHeaderObjectPage--template::ImplementingComponentContent---idSalesQuotationDetails--idSQDetailsLayout-anchBar").getContent()[1].setVisible(false);

					// Hiding Standard Submit button 
					this.getView().byId("cus.sd.sq.mccs1::sap.suite.ui.generic.template.Canvas.view.Canvas::navigateToHeaderObjectPage--template::ImplementingComponentContent---idSalesQuotationDetails--headerObjectPageSubmitBtn").setVisible(false);

					// Hiding Standard Cancel button 
					this.getView().byId("cus.sd.sq.mccs1::sap.suite.ui.generic.template.Canvas.view.Canvas::navigateToHeaderObjectPage--template::ImplementingComponentContent---idSalesQuotationDetails--idSQDetailsCancel").setVisible(false);

					// bind data to group elements
					let oGroup1 = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2._IDGroupElement1"),
						oGroup2 = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2._IDGroupElement2"),
						oGroup3 = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2._IDGroupElement3");
					oGroup1.bindElement("localModel>/basicData/deliveryDate"),
						oGroup2.bindElement("localModel>/basicData/validFrom"),
						oGroup3.bindElement("localModel>/basicData/validTo");

					// Get Quotations Data
					let oSmartForm = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2._IDSmartForm1");

					oSmartForm.attachModelContextChange(function (oEvt) {
						if (this.getView().getModel("localIconModel").getData().check === false) {
							let oCustomerModel = this.getView().getModel("customer.quotations");
							oCustomerModel.read("/ETS_QTN_ITEMSet", {
								success: function (data) {
									this._processData(data.results);
									var oData = this.getView().getModel("localIconModel").getData();
									oData.check = true;
									this.getView().getModel("localIconModel").setData(oData);
								}.bind(this),
								error: function (error) {
									// nothing to be done as of now
								}
							});
						} else {
							// setting check flag when navigating to back screen
							var oData = this.getView().getModel("localIconModel").getData();
							oData.check = false;
							this.getView().getModel("localIconModel").setData(oData);
						}

					}.bind(this));
				},

				// 	/**
				// 	 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
				// 	 * @memberOf customer.zsdsqmccs1.v2.changesHeader
				// 	 */
				// 	onExit: function() {
				// 	},

				// 	// override public method of the base controller
				// 	basePublicMethod: function() {
				// 	}
			},

			onMenuAction: function (oEvt) {
				let sSelectedKey = oEvt.getParameter("item").getKey();
				let oChangeModel = this.getView().getModel("localModel").getData();

				let a = oEvt.getSource().getParent(),
					b = a.getParent(),
					c = b.getParent(),
					d = c.getParent();
				if (sSelectedKey === "CCV") {
					c.getItems()[2].getItems()[0].setVisible(false);
					c.getItems()[2].getItems()[1].setVisible(true);
					c.getItems()[5].getItems()[1].setVisible(true);
				} else {
					c.getItems()[2].getItems()[0].setVisible(false);
					c.getItems()[2].getItems()[1].setVisible(true);
					c.getItems()[5].getItems()[0].setVisible(true);
					c.getItems()[5].getItems()[1].setVisible(true);
				}

				if (d.getElementBinding("localModel").getPath() === "/basicData/deliveryDate") {
					oChangeModel.basicData.deliveryDate.currentOperation = sSelectedKey;
				} else if (d.getElementBinding("localModel").getPath() === "/basicData/validFrom") {
					oChangeModel.basicData.validFrom.currentOperation = sSelectedKey;
				} else if (d.getElementBinding("localModel").getPath() === "/basicData/validTo") {
					oChangeModel.basicData.validTo.currentOperation = sSelectedKey;
				}
				this.getView().getModel("localModel").setData(oChangeModel);
			},

			onClickUndo: function (oEvt) {
				let oChangeModel = this.getView().getModel("localModel").getData();

				let a = oEvt.getSource().getParent(),
					b = a.getParent(),
					c = b.getParent();

				if (c.getElementBinding("localModel").getPath() === "/basicData/deliveryDate") {
					var sSelectedKey = oChangeModel.basicData.deliveryDate.currentOperation;
				} else if (c.getElementBinding("localModel").getPath() === "/basicData/validFrom") {
					sSelectedKey = oChangeModel.basicData.validFrom.currentOperation;
				} else if (c.getElementBinding("localModel").getPath() === "/basicData/validTo") {
					sSelectedKey = oChangeModel.basicData.validTo.currentOperation;
				}

				if (sSelectedKey === "CCV") {
					a.getItems()[1].setVisible(false);
					b.getItems()[2].getItems()[0].setVisible(true);
					b.getItems()[2].getItems()[1].setVisible(false);
					b.getItems()[4].setValue("");
				} else {
					b.getItems()[2].getItems()[0].setVisible(true);
					b.getItems()[2].getItems()[1].setVisible(false);
					a.getItems()[0].setVisible(false);
					a.getItems()[1].setVisible(false);
				}

				if (c.getElementBinding("localModel").getPath() === "/basicData/deliveryDate") {
					oChangeModel.basicData.deliveryDate.currentOperation = "";
				} else if (c.getElementBinding("localModel").getPath() === "/basicData/validFrom") {
					oChangeModel.basicData.validFrom.currentOperation = "";
				} else if (c.getElementBinding("localModel").getPath() === "/basicData/validTo") {
					oChangeModel.basicData.validTo.currentOperation = "";
				}

				this.getView().getModel("localModel").setData(oChangeModel);
			},

			_processData: function (data) {
				let oIconData = this.getView().getModel("localIconModel").getData();
				let validFrom = [], validTo = [];

				let count = 0;
				// Start variable is used to set true
				// if a repeated duplicate value is
				// encontered in the output array.
				let start = false;

				for (let j = 0; j < data.length; j++) {
					for (let k = 0; k < validFrom.length; k++) {
						if (data[j].ANGDT.getTime() == validFrom[k].ANGDT.getTime()) {
							start = true;
						}
					}
					count++;
					if (count == 1 && start == false) {
						validFrom.push(data[j]);
					}
					start = false;
					count = 0;
				}

				for (let i = 0; i < data.length; i++) {
					for (let j = 0; j < validTo.length; j++) {
						if (data[i].BNDDT.getTime() == validTo[j].BNDDT.getTime()) {
							start = true;
						}
					}
					count++;
					if (count == 1 && start == false) {
						validTo.push(data[i]);
					}
					start = false;
					count = 0;
				}

				if (validFrom.length > 1) {
					oIconData.validFrom = true;
				}

				if (validTo.length > 1) {
					oIconData.validTo = true;
				}

				this.getView().getModel("localIconModel").setData(oIconData);

				this.getView().getModel("localModel").setProperty("/Quotations", data);
			},

			onHdrSubmit: function () {
				let sChangeData = this.getView().getModel("changeModel").getData(),
					aQuotations = this.getView().getModel("localModel").getProperty("/Quotations");

				if (sChangeData.deliveryDate === "" && sChangeData.validFrom === "" && sChangeData.validTo === "") {
					MessageBox.error("No values entered for mass change");
				} else if (sChangeData.deliveryDateValid !== true || sChangeData.validFromValid !== true || sChangeData.validToValid !== true) {
					MessageBox.error("Enter proper date values");
				} else {
					let aItems = [],
						oCustomerModel = this.getView().getModel("customer.quotations");

					if (sChangeData.deliveryDate !== "" && sChangeData.deliveryDateValid === true) {
						var sDeliveryDate = this._dateFormat().format(this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2.idDateInput1").getDateValue());
					}

					if (sChangeData.validFrom !== "" && sChangeData.validFromValid === true) {
						var sFromDate = this._dateFormat().format(this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2.idDateInput2").getDateValue());
					}

					if (sChangeData.validTo !== "" && sChangeData.validToValid === true) {
						var sToDate = this._dateFormat().format(this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2.idDateInput3").getDateValue());
					}

					aQuotations.forEach((element) => {
						let oItems = {};

						oItems.VBELN = element.VBELN;
						if (sDeliveryDate) {
							oItems.VDATU = sDeliveryDate;
						}
						if (sFromDate) {
							oItems.ANGDT = sFromDate;
						}
						if (sToDate) {
							oItems.BNDDT = sToDate;
						}
						aItems.push(oItems);
					});

					let oFinalPayload = {
						VBELN: aItems[0].VBELN,
						CHG_QTN: aItems
					};

					this.getView().setBusy(true);
					oCustomerModel.create("/ETS_CHG_QTN_HDRSet", oFinalPayload, {
						success: function (data) {
							this.getView().setBusy(false);
							MessageBox.success("Please check your email for job confirmation");
							this._deleteQuotations();
						}.bind(this),
						error: function (error) {
							this.getView().setBusy(false);
							var sPattern = new RegExp("[{}]");
							var sSstrMatch = error.responseText.match(sPattern);
							if (sSstrMatch) {
								var sMsg = JSON.parse(error.responseText);
								MessageBox.error(sMsg.error.message.value);
							} else {
								MessageBox.error(error.responseText);
							}
						}.bind(this)
					});
				}
			},

			onHdrCancel: function () {
				var oData = this.getView().getModel("localIconModel").getData();
				oData.check = true;
				oData.validFrom = false;
				oData.validTo = false;
				this.getView().getModel("localIconModel").setData(oData);

				// navigating back
				window.history.go(-1);

				// refresh input entries and screen
				let oChangeData = this.getView().getModel("changeModel").getData();
				oChangeData.deliveryDate = "";
				oChangeData.validFrom = "";
				oChangeData.validTo = "";
				this.getView().getModel("changeModel").setData(oChangeData);

				let oform = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2._IDGroup1");
				oform.getFormElements().forEach((element, idx) => {
					let aItems = element.getFormElement().getFields()[0].getItems();
					aItems[2].getItems()[0].setVisible(true);
					aItems[2].getItems()[1].setVisible(false);
					aItems[5].getItems()[0].setVisible(false);
					aItems[5].getItems()[1].setVisible(false);
				});

				let oChangeModel = this.getView().getModel("localModel").getData();
				oChangeModel.basicData.deliveryDate.currentOperation = "";
				oChangeModel.basicData.validFrom.currentOperation = "";
				oChangeModel.basicData.validTo.currentOperation = "";

				this.getView().getModel("localModel").setData(oChangeModel);

			},

			_deleteQuotations: function () {
				let sPath = "/ETS_QTN_ITEMSet",
					aFilter = [];

				aFilter.push(
					new Filter({
						filters: [
							new Filter("DELETE_FLAG", FilterOperator.EQ, "X"),
						],
					})
				);
				var mParameters = {
					filters: aFilter
				}
				this.getView().getModel("customer.quotations").read(sPath, mParameters);

				let oChangeData = this.getView().getModel("changeModel").getData();
				oChangeData.deliveryDate = "";
				oChangeData.validFrom = "";
				oChangeData.validTo = "";
				this.getView().getModel("changeModel").setData(oChangeData);
			},

			_dateFormat: function () {
				var oDateformat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy-MM-ddTHH:mm:ss",
				});

				return oDateformat;
			},

			onDelvDateChange: function (oEvt) {
				let oChangeData = this.getView().getModel("changeModel").getData();
				oChangeData.deliveryDateValid = oEvt.getParameter('valid');
				if (oEvt.getParameter('valid') === false) {
					oEvt.getSource().setValueState('Error');
					MessageBox.error("Enter date in this format: MM/DD/YYYY.");
				} else {
					oEvt.getSource().setValueState('None');
				}

				this.getView().getModel("changeModel").setData(oChangeData);
			},

			onValidFromChange: function (oEvt) {
				let oChangeData = this.getView().getModel("changeModel").getData();
				oChangeData.validFromValid = oEvt.getParameter('valid');
				if (oEvt.getParameter('valid') === false) {
					oEvt.getSource().setValueState('Error');
					MessageBox.error("Enter date in this format: MM/DD/YYYY.");
				} else {
					oEvt.getSource().setValueState('None');
				}
				this.getView().getModel("changeModel").setData(oChangeData);
			},

			onValidToChange: function (oEvt) {
				let oChangeData = this.getView().getModel("changeModel").getData();
				oChangeData.validToValid = oEvt.getParameter('valid');
				if (oEvt.getParameter('valid') === false) {
					oEvt.getSource().setValueState('Error');
					MessageBox.error("Enter date in this format: MM/DD/YYYY.");
				} else {
					oEvt.getSource().setValueState('None');
				}
				this.getView().getModel("changeModel").setData(oChangeData);
			}
		});
	});