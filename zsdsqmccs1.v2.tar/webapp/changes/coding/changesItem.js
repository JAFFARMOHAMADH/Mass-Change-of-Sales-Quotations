/***
@controller Name:cus.sd.so.mccs1.ext.salesquotationitemdetails.SalesQuotationItemDetails,
*@viewId:cus.sd.sq.mccs1::sap.suite.ui.generic.template.Canvas.view.Canvas::navigateToItemObjectPage--template::ImplementingComponentContent---idSalesQuotationItemDetails
*/
/*!
 * OpenUI5
 * (c) Copyright 2009-2022 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */

sap.ui.define([
	'sap/ui/core/mvc/ControllerExtension',
	'sap/ui/model/json/JSONModel',
	'sap/ui/core/Fragment',
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	'sap/m/MessageBox'
	// ,'sap/ui/core/mvc/OverrideExecution'
],
	function (
		ControllerExtension,
		JSONModel,
		Fragment,
		Filter,
		FilterOperator,
		MessageBox
		// ,OverrideExecution
	) {
		"use strict";
		return ControllerExtension.extend("customer.zsdsqmccs1.v2.changesItem", {
			// metadata: {
			// 	// extension can declare the public methods
			// 	// in general methods that start with "_" are private
			// 	methods: {
			// 		publicMethod: {
			// 			public: true /*default*/ ,
			// 			final: false /*default*/ ,
			// 			overrideExecution: OverrideExecution.Instead /*default*/
			// 		},
			// 		finalPublicMethod: {
			// 			final: true
			// 		},
			// 		onMyHook: {
			// 			public: true /*default*/ ,
			// 			final: false /*default*/ ,
			// 			overrideExecution: OverrideExecution.After
			// 		},
			// 		couldBePrivate: {
			// 			public: false
			// 		}
			// 	}
			// },

			// // adding a private method, only accessible from this controller extension
			// _privateMethod: function() {},
			// // adding a public method, might be called from or overridden by other controller extensions as well
			// publicMethod: function() {},
			// // adding final public method, might be called from, but not overridden by other controller extensions as well
			// finalPublicMethod: function() {},
			// // adding a hook method, might be called by or overridden from other controller extensions
			// // override these method does not replace the implementation, but executes after the original method
			// onMyHook: function() {},
			// // method public per default, but made private via metadata
			// couldBePrivate: function() {},
			// // this section allows to extend lifecycle hooks or override public methods of the base controller
			override: {
				// 	/**
				// 	 * Called when a controller is instantiated and its View controls (if available) are already created.
				// 	 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
				// 	 * @memberOf customer.zsdsqmccs1.v2.changesItem
				// 	 */
				onInit: function () {
					let oChangeItemData = {
						material: "",
						plant: "",
						condType: "",
						price: "",
						currency: "",
						quantity: "",
						unit: "",
						volume: "",
						volUnit: "",
					};

					let oIconData = {
						materialIcon: false,
						quantityIcon: false,
						check: false
					};

					let oLocalItemData = {
						"basicData": {
							"deliveryDate": {
								"visible": true,
								"enabled": true,
								"currentOperation": ""
							},
							"validFrom": {
								"visible": true,
								"enabled": true,
								"currentOperation": ""
							},
							"validTo": {
								"visible": true,
								"enabled": true,
								"currentOperation": ""
							},
							"material": {
								"visible": true,
								"enabled": true,
								"currentOperation": ""
							},
							"plant": {
								"visible": true,
								"enabled": true,
								"currentOperation": ""
							},
							"price": {
								"visible": true,
								"enabled": true,
								"currentOperation": ""
							},
							"quantity": {
								"visible": true,
								"enabled": true,
								"currentOperation": ""
							},
							"volume": {
								"visible": true,
								"enabled": true,
								"currentOperation": ""
							}
						},
						"page": "item"
					};

					var oLocalItemModel = new JSONModel(),
						oChangeItemModel = new JSONModel(),
						oIconItemModel = new JSONModel();

					// oLocalItemModel.loadData("../webapp/changes/localData.json", false);
					// oLocalItemModel.attachRequestCompleted(function (oEvt) {
					// 	let oData = oEvt.getSource().getData();
					// 	oData.page = "item";
					// 	this.getView().getModel("localModel").setData(oEvt.getSource().getData());
					// }.bind(this));

					oLocalItemModel.setData(oLocalItemData);
					this.getView().setModel(oLocalItemModel, "localModel");

					oChangeItemModel.setData(oChangeItemData);
					this.getView().setModel(oChangeItemModel, "changeItemModel");

					oIconItemModel.setData(oIconData);
					this.getView().setModel(oIconItemModel, "localIconModel");

					// Get Quotations Data
					let oSmartForm = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2._IDSmartFormItem1");

					oSmartForm.attachModelContextChange(function (oEvt) {
						if (this.getView().getModel("localIconModel").getData().check === false) {
							let oCustomerModel = this.getView().getModel("customer.quotations");
							oCustomerModel.read("/ETS_QTN_ITEMSet", {
								success: function (data) {
									this._processData(data.results);
									var oData = this.getView().getModel("localIconModel").getData();
									oData.check = true;
									this.getView().getModel("localIconModel").setData(oData);
								}.bind(this),
								error: function (error) {
									// nothing to be done as of now
								}
							});
						} else {
							// setting check flag when navigating to back screen
							var oData = this.getView().getModel("localIconModel").getData();
							oData.check = false;
							this.getView().getModel("localIconModel").setData(oData);
						}

					}.bind(this));
				},

				// 	/**
				// 	 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
				// 	 * (NOT before the first rendering! onInit() is used for that one!).
				// 	 * @memberOf customer.zsdsqmccs1.v2.changesItem
				// 	 */
				// 	onBeforeRendering: function() {
				// 	},

				// 	/**
				// 	 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
				// 	 * This hook is the same one that SAPUI5 controls get after being rendered.
				// 	 * @memberOf customer.zsdsqmccs1.v2.changesItem
				// 	 */
				onAfterRendering: function () {
					// Hiding the existing standard fields
					this.getView().byId("cus.sd.sq.mccs1::sap.suite.ui.generic.template.Canvas.view.Canvas::navigateToItemObjectPage--template::ImplementingComponentContent---idSalesQuotationItemDetails--idSQItemDetailsBasicDataSubSection").getBlocks()[0].setVisible(false);

					// Hiding Terms and Conditions block
					this.getView().byId("cus.sd.sq.mccs1::sap.suite.ui.generic.template.Canvas.view.Canvas::navigateToItemObjectPage--template::ImplementingComponentContent---idSalesQuotationItemDetails--idSQItemDetailsLayout-anchBar").getContent()[1].setVisible(false);

					// Hiding Standard Submit button 
					this.getView().byId("cus.sd.sq.mccs1::sap.suite.ui.generic.template.Canvas.view.Canvas::navigateToItemObjectPage--template::ImplementingComponentContent---idSalesQuotationItemDetails--itemObjectPageSubmitBtn").setVisible(false);

					// Hiding Standard Cancel button 
					this.getView().byId("cus.sd.sq.mccs1::sap.suite.ui.generic.template.Canvas.view.Canvas::navigateToItemObjectPage--template::ImplementingComponentContent---idSalesQuotationItemDetails--idSQItemDetailsCancel").setVisible(false);

					// bind data to group elements
					let oItemGroup1 = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2._IDGroupElementitem1"),
						oItemGroup2 = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2._IDGroupElementitem2"),
						oItemGroup3 = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2._IDGroupElementitem3"),
						oItemGroup4 = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2._IDGroupElementitem4"),
						oItemGroup5 = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2._IDGroupElementitem5");
					oItemGroup1.bindElement("localModel>/basicData/plant"),
						oItemGroup2.bindElement("localModel>/basicData/material"),
						oItemGroup3.bindElement("localModel>/basicData/quantity"),
						oItemGroup4.bindElement("localModel>/basicData/volume"),
						oItemGroup5.bindElement("localModel>/basicData/price");
				},

				// 	/**
				// 	 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
				// 	 * @memberOf customer.zsdsqmccs1.v2.changesItem
				// 	 */
				// 	onExit: function() {
				// 	},

				// 	// override public method of the base controller
				// 	basePublicMethod: function() {
				// 	}
			},

			onMenuAction: function (oEvt) {
				let sSelectedKey = oEvt.getParameter("item").getKey();
				let oChangeModel = this.getView().getModel("localModel").getData();

				let a = oEvt.getSource().getParent(),
					b = a.getParent(),
					c = b.getParent(),
					d = c.getParent();
				if (sSelectedKey === "CCV") {
					c.getItems()[3].getItems()[0].setVisible(false);
					c.getItems()[3].getItems()[1].setVisible(true);
					c.getItems()[6].getItems()[1].setVisible(true);
				} else {
					c.getItems()[3].getItems()[0].setVisible(false);
					c.getItems()[3].getItems()[1].setVisible(true);
					c.getItems()[6].getItems()[0].setVisible(true);
					c.getItems()[6].getItems()[1].setVisible(true);
				}

				if (d.getElementBinding("localModel").getPath() === "/basicData/plant") {
					oChangeModel.basicData.plant.currentOperation = sSelectedKey;
				} else if (d.getElementBinding("localModel").getPath() === "/basicData/material") {
					oChangeModel.basicData.material.currentOperation = sSelectedKey;
				} else if (d.getElementBinding("localModel").getPath() === "/basicData/price") {
					oChangeModel.basicData.price.currentOperation = sSelectedKey;
				} else if (d.getElementBinding("localModel").getPath() === "/basicData/quantity") {
					oChangeModel.basicData.quantity.currentOperation = sSelectedKey;
				} else if (d.getElementBinding("localModel").getPath() === "/basicData/volume") {
					oChangeModel.basicData.volume.currentOperation = sSelectedKey;
				}

				this.getView().getModel("localModel").setData(oChangeModel);
			},

			onClickUndo: function (oEvt) {
				let oChangeModel = this.getView().getModel("localModel").getData();

				let a = oEvt.getSource().getParent(),
					b = a.getParent(),
					c = b.getParent();

				if (c.getElementBinding("localModel").getPath() === "/basicData/plant") {
					var sSelectedKey = oChangeModel.basicData.plant.currentOperation;
				} else if (c.getElementBinding("localModel").getPath() === "/basicData/material") {
					sSelectedKey = oChangeModel.basicData.material.currentOperation;
				} else if (c.getElementBinding("localModel").getPath() === "/basicData/price") {
					sSelectedKey = oChangeModel.basicData.price.currentOperation;
				} else if (c.getElementBinding("localModel").getPath() === "/basicData/quantity") {
					sSelectedKey = oChangeModel.basicData.quantity.currentOperation;
				} else if (c.getElementBinding("localModel").getPath() === "/basicData/volume") {
					sSelectedKey = oChangeModel.basicData.volume.currentOperation;
				}

				if (sSelectedKey === "CCV") {
					a.getItems()[1].setVisible(false);
					b.getItems()[3].getItems()[0].setVisible(true);
					b.getItems()[3].getItems()[1].setVisible(false);

					if ((c.getLabel() === "Order Quantity") || (c.getLabel() === "Volume")) {
						b.getItems()[4].getItems()[0].setValue("");
						b.getItems()[4].getItems()[1].setValue("");
					} else {
						b.getItems()[4].setValue("");
					}
				} else {
					b.getItems()[3].getItems()[0].setVisible(true);
					b.getItems()[3].getItems()[1].setVisible(false);
					a.getItems()[0].setVisible(false);
					a.getItems()[1].setVisible(false);
				}

				if (c.getElementBinding("localModel").getPath() === "/basicData/plant") {
					oChangeModel.basicData.plant.currentOperation = "";
				} else if (c.getElementBinding("localModel").getPath() === "/basicData/material") {
					oChangeModel.basicData.material.currentOperation = "";
				} else if (c.getElementBinding("localModel").getPath() === "/basicData/price") {
					oChangeModel.basicData.price.currentOperation = "";
				} else if (c.getElementBinding("localModel").getPath() === "/basicData/quantity") {
					oChangeModel.basicData.quantity.currentOperation = "";
				} else if (c.getElementBinding("localModel").getPath() === "/basicData/volume") {
					oChangeModel.basicData.volume.currentOperation = "";
				}

				this.getView().getModel("localModel").setData(oChangeModel);

			},

			onMaterial: function (oEvent) {
				var sInputValue = oEvent.getSource().getValue();
				if (!this._pValueHelpDialog) {
					this._pValueHelpDialog = Fragment.load({
						id: this.getView().getId(),
						name: "customer.zsdsqmccs1.v2.changes.fragments.Material",
						controller: this
					}).then(function (oDialog) {
						this.getView().addDependent(oDialog);
						return oDialog;
					}.bind(this));
				}
				this._pValueHelpDialog.then(function (oDialog) {
					// Create a filter for the binding
					oDialog.getBinding("items").filter([new Filter("MATNR", FilterOperator.Contains, sInputValue)]);
					// Open ValueHelpDialog filtered by the input's value
					oDialog.open(sInputValue);
				});
			},

			handleClose: function (oEvent) {
				var oSelectedItem = oEvent.getParameter("selectedItem"),
					oInput = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2.idMatInputItem");

				if (!oSelectedItem) {
					oInput.resetProperty("value");
					return;
				}

				oInput.setValue(oSelectedItem.getCells()[0].getTitle());
				oEvent.getSource().getBinding("items").filter([]);
			},

			handleSearch: function (oEvent) {
				var sValue = oEvent.getParameter("value");
				if (sValue !== "") {
					var oFilter = [];
					var pattern = new RegExp("[ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz]");
					var strMatch = sValue.match(pattern);
					if (strMatch) {
						oFilter.push(
							new Filter({
								filters: [
									new Filter(
										"MAKTX",
										FilterOperator.Contains,
										sValue
									),
								],
							})
						);
					} else {
						oFilter.push(
							new Filter({
								filters: [
									new Filter(
										"MATNR",
										FilterOperator.Contains,
										sValue
									),
								],
							})
						);
					}

					oEvent.getSource().getBinding("items").filter(oFilter);
				} else {
					oEvent.getSource().getBinding("items").filter([
						new Filter(
							"MATNR",
							FilterOperator.Contains,
							sValue
						),
					]);
				}
			},

			onPlant: function (oEvent) {
				var sInputValue = oEvent.getSource().getValue();
				if (!this._plantValueHelpDialog) {
					this._plantValueHelpDialog = Fragment.load({
						id: this.getView().getId(),
						name: "customer.zsdsqmccs1.v2.changes.fragments.Plant",
						controller: this
					}).then(function (oDialog) {
						this.getView().addDependent(oDialog);
						return oDialog;
					}.bind(this));
				}

				this._plantValueHelpDialog.then(function (oDialog) {
					// 	// Create a filter for the binding
					oDialog.getBinding("items").filter([new Filter("WERKS", FilterOperator.Contains, sInputValue)]);
					// 	// Open ValueHelpDialog filtered by the input's value
					oDialog.open(sInputValue);
				});
			},

			handlePlantClose: function (oEvent) {
				var oSelectedItem = oEvent.getParameter("selectedItem"),
					oInput = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2.idPlantInputItem");

				if (!oSelectedItem) {
					oInput.resetProperty("value");
					return;
				}

				oInput.setValue(oSelectedItem.getCells()[0].getTitle());
				oEvent.getSource().getBinding("items").filter([]);
			},

			handlePlantSearch: function (oEvent) {
				var sValue = oEvent.getParameter("value");
				var oFilter = [], oFilters = [];
				if (sValue !== "") {
					oFilter.push(
						new Filter({
							filters: [
								new Filter(
									"MATNR",
									FilterOperator.Contains,
									sValue
								),
							],
						})
					);

					if (sValue.length > 4) {
						var arr = [4],
							sNewValue = this.splitByLengths(sValue, arr);
						sValue = sNewValue[0];
					}
					oFilter.push(
						new Filter({
							filters: [
								new Filter(
									"WERKS",
									FilterOperator.Contains,
									sValue
								),
							],
						})
					);
					oFilters.push(
						new Filter({
							filters: oFilter,
							and: false
						})
					);
					oEvent.getSource().getBinding("items").filter(oFilters);
				} else {
					oEvent.getSource().getBinding("items").filter([
						new Filter(
							"WERKS",
							FilterOperator.Contains,
							sValue
						),
					]);
				}
			},

			splitByLengths: function (str, arr) {
				var id = 0;
				var outputArr = [];
				arr.forEach(function (len) {
					outputArr.push(str.slice(id, id + len));
					id += len;
				});
				return outputArr;
			},

			onUnit: function (oEvent) {
				var sInputValue = oEvent.getSource().getValue();
				if (!this._unitValueHelpDialog) {
					this._unitValueHelpDialog = Fragment.load({
						id: this.getView().getId(),
						name: "customer.zsdsqmccs1.v2.changes.fragments.Quantity",
						controller: this
					}).then(function (oDialog) {
						this.getView().addDependent(oDialog);
						return oDialog;
					}.bind(this));
				}

				this._unitValueHelpDialog.then(function (oDialog) {
					// Create a filter for the binding
					oDialog.getBinding("items").filter([new Filter("MEINH", FilterOperator.Contains, sInputValue)]);
					// Open ValueHelpDialog filtered by the input's value
					oDialog.open(sInputValue);
				});
			},

			handleQtyClose: function (oEvent) {
				var oSelectedItem = oEvent.getParameter("selectedItem"),
					oInput = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2.idUnitInputItem");

				if (!oSelectedItem) {
					oInput.resetProperty("value");
					return;
				}

				oInput.setValue(oSelectedItem.getCells()[0].getTitle());
				oEvent.getSource().getBinding("items").filter([]);
			},

			handleQtySearch: function (oEvent) {
				var sValue = oEvent.getParameter("value");
				var oFilter = [], oFilters = [];
				if (sValue !== "") {
					oFilter.push(
						new Filter({
							filters: [
								new Filter(
									"MATNR",
									FilterOperator.Contains,
									sValue
								),
							],
						})
					);

					if (sValue.length > 3) {
						var arr = [3],
							sNewValue = this.splitByLengths(sValue, arr);
						sValue = sNewValue[0];
					}
					oFilter.push(
						new Filter({
							filters: [
								new Filter(
									"MEINH",
									FilterOperator.Contains,
									sValue
								),
							],
						})
					);

					oFilters.push(
						new Filter({
							filters: oFilter,
							and: false
						})
					);

					oEvent.getSource().getBinding("items").filter(oFilters);
				} else {
					oEvent.getSource().getBinding("items").filter([
						new Filter(
							"MEINH",
							FilterOperator.Contains,
							sValue
						),
					]);
				}
			},

			onVolume: function (oEvent) {
				var sInputValue = oEvent.getSource().getValue();
				if (!this._volValueHelpDialog) {
					this._volValueHelpDialog = Fragment.load({
						id: this.getView().getId(),
						name: "customer.zsdsqmccs1.v2.changes.fragments.Volume",
						controller: this
					}).then(function (oDialog) {
						this.getView().addDependent(oDialog);
						return oDialog;
					}.bind(this));
				}

				this._volValueHelpDialog.then(function (oDialog) {
					// Create a filter for the binding
					oDialog.getBinding("items").filter([new Filter("UNITOFMEASURE", FilterOperator.Contains, sInputValue)]);
					// Open ValueHelpDialog filtered by the input's value
					oDialog.open(sInputValue);
				});
			},

			handleVolumeClose: function (oEvent) {
				var oSelectedItem = oEvent.getParameter("selectedItem"),
					oInput = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2.idVolUnitInputItem");

				if (!oSelectedItem) {
					oInput.resetProperty("value");
					return;
				}

				oInput.setValue(oSelectedItem.getCells()[0].getTitle());
				oEvent.getSource().getBinding("items").filter([]);
			},

			handleVolumeSearch: function (oEvent) {
				var sValue = oEvent.getParameter("value");
				var oFilter = [], oFilters = [];
				if (sValue !== "") {
					oFilter.push(
						new Filter({
							filters: [
								new Filter(
									"UNITOFMEASURELONGNAME",
									FilterOperator.Contains,
									sValue
								),
							],
						})
					);

					oFilter.push(
						new Filter({
							filters: [
								new Filter(
									"UNITOFMEASUREDIMENSIONNAME",
									FilterOperator.Contains,
									sValue
								),
							],
						})
					);

					if (sValue.length > 3) {
						var arr = [3],
							sNewValue = this.splitByLengths(sValue, arr);
						sValue = sNewValue[0];
					}

					oFilter.push(
						new Filter({
							filters: [
								new Filter(
									"UNITOFMEASURE",
									FilterOperator.Contains,
									sValue
								),
							],
						})
					);

					oFilter.push(
						new Filter({
							filters: [
								new Filter(
									"UNITOFMEASURE_E",
									FilterOperator.Contains,
									sValue
								),
							],
						})
					);

					oFilters.push(
						new Filter({
							filters: oFilter,
							and: false
						})
					);

					oEvent.getSource().getBinding("items").filter(oFilters);
				} else {
					oEvent.getSource().getBinding("items").filter([
						new Filter(
							"UNITOFMEASURE",
							FilterOperator.Contains,
							sValue
						),
					]);
				}
			},

			onCondType: function (oEvent) {
				var sInputValue = oEvent.getSource().getValue();
				if (!this._condTypeValueHelpDialog) {
					this._condTypeValueHelpDialog = Fragment.load({
						id: this.getView().getId(),
						name: "customer.zsdsqmccs1.v2.changes.fragments.CondType",
						controller: this
					}).then(function (oDialog) {
						this.getView().addDependent(oDialog);
						return oDialog;
					}.bind(this));
				}

				this._condTypeValueHelpDialog.then(function (oDialog) {
					// Create a filter for the binding
					oDialog.getBinding("items").filter([new Filter("KSCHL", FilterOperator.Contains, sInputValue)]);
					// Open ValueHelpDialog filtered by the input's value
					oDialog.open(sInputValue);
				});
			},

			handleCondClose: function (oEvent) {
				var oSelectedItem = oEvent.getParameter("selectedItem"),
					oInput = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2.idCondInputItem");

				if (!oSelectedItem) {
					oInput.resetProperty("value");
					return;
				}

				oInput.setValue(oSelectedItem.getCells()[0].getTitle());
				oEvent.getSource().getBinding("items").filter([]);
			},

			handleCondSearch: function (oEvent) {
				var sValue = oEvent.getParameter("value");
				var oFilter = [];
				oFilter.push(
					new Filter({
						filters: [
							new Filter(
								"KSCHL",
								FilterOperator.Contains,
								sValue
							),
						],
					})
				);

				oEvent.getSource().getBinding("items").filter(oFilter);
			},

			onCurrency: function (oEvent) {
				var sInputValue = oEvent.getSource().getValue();
				if (!this._currencyValueHelpDialog) {
					this._currencyValueHelpDialog = Fragment.load({
						id: this.getView().getId(),
						name: "customer.zsdsqmccs1.v2.changes.fragments.Currency",
						controller: this
					}).then(function (oDialog) {
						this.getView().addDependent(oDialog);
						return oDialog;
					}.bind(this));
				}

				this._currencyValueHelpDialog.then(function (oDialog) {
					// Create a filter for the binding
					oDialog.getBinding("items").filter([new Filter("WAERS", FilterOperator.Contains, sInputValue)]);
					// Open ValueHelpDialog filtered by the input's value
					oDialog.open(sInputValue);
				});
			},

			handleCurrClose: function (oEvent) {
				var oSelectedItem = oEvent.getParameter("selectedItem"),
					oInput = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2.idCurrencyInputItem");

				if (!oSelectedItem) {
					oInput.resetProperty("value");
					return;
				}

				oInput.setValue(oSelectedItem.getCells()[0].getTitle());
				oEvent.getSource().getBinding("items").filter([]);
			},

			handleCurrSearch: function (oEvent) {
				var sValue = oEvent.getParameter("value");
				var oFilter = [], oFilters = [];
				if (sValue !== "") {
					oFilter.push(
						new Filter({
							filters: [
								new Filter(
									"LTEXT",
									FilterOperator.Contains,
									sValue
								),
							],
						})
					);

					if (sValue.length > 5) {
						var arr = [5],
							sNewValue = this.splitByLengths(sValue, arr);
						sValue = sNewValue[0];
					}

					oFilter.push(
						new Filter({
							filters: [
								new Filter(
									"WAERS",
									FilterOperator.Contains,
									sValue
								),
							],
						})
					);

					oFilters.push(
						new Filter({
							filters: oFilter,
							and: false
						})
					);

					oEvent.getSource().getBinding("items").filter(oFilters);
				} else {
					oEvent.getSource().getBinding("items").filter([
						new Filter(
							"WAERS",
							FilterOperator.Contains,
							sValue
						),
					]);
				}
			},

			onItemSubmit: function () {
				let sChangeData = this.getView().getModel("changeItemModel").getData(),
					aQuotations = this.getView().getModel("localModel").getProperty("/Quotations");

				if (sChangeData.plant === "" && sChangeData.material === "" && sChangeData.quantity === "" && sChangeData.volume === "" && sChangeData.price === "") {
					MessageBox.error("No values entered for mass change");
				} else if ((sChangeData.quantity !== "" && sChangeData.unit === "") || (sChangeData.quantity === "" && sChangeData.unit !== "")) {
					MessageBox.error("Please enter order quantity along with units");
				} else if ((sChangeData.volume !== "" && sChangeData.volUnit === "") || (sChangeData.volume === "" && sChangeData.volUnit !== "")) {
					MessageBox.error("Please enter volume along with units");
				} else if ((sChangeData.condType !== "" && sChangeData.price === "" && sChangeData.currency === "") || (sChangeData.condType === "" && sChangeData.price !== "" && sChangeData.currency === "") || (sChangeData.condType === "" && sChangeData.price === "" && sChangeData.currency !== "")) {
					MessageBox.error("Please enter price along with condition type and currency");
				} else {
					let aItems = [],
						oCustomerModel = this.getView().getModel("customer.quotations");

					aQuotations.forEach((element) => {
						let oItems = {};

						oItems.VBELN = element.VBELN;
						oItems.POSNR = element.POSNR;

						if (sChangeData.plant !== "") {
							oItems.WERKS = sChangeData.plant;
						}
						if (sChangeData.material !== "") {
							oItems.MATNR = sChangeData.material;
						}
						if (sChangeData.quantity !== "" && sChangeData.unit !== "") {
							oItems.KWMENG = sChangeData.quantity;
							oItems.VRKME = sChangeData.unit;
						}
						if (sChangeData.volume !== "" && sChangeData.volUnit !== "") {
							oItems.VOLUM = sChangeData.volume;
							oItems.VOLEH = sChangeData.volUnit;
						}
						if (sChangeData.condType !== "" && sChangeData.price !== "" && sChangeData.currency !== "") {
							oItems.KSCHL = sChangeData.condType;
							oItems.KBETR = sChangeData.price;
							oItems.WAERS = sChangeData.currency;
						}
						aItems.push(oItems);
					});

					let oFinalPayload = {
						VBELN: aItems[0].VBELN,
						CHG_QTN: aItems
					};

					this.getView().setBusy(true);
					oCustomerModel.create("/ETS_CHG_QTN_HDRSet", oFinalPayload, {
						success: function (data) {
							this.getView().setBusy(false);
							MessageBox.success("Please check your email for job confirmation");
							this._deleteQuotations();
						}.bind(this),
						error: function (error) {
							this.getView().setBusy(false);
							var sPattern = new RegExp("[{}]");
							var sSstrMatch = error.responseText.match(sPattern);
							if (sSstrMatch) {
								var sMsg = JSON.parse(error.responseText);
								MessageBox.error(sMsg.error.message.value);
							} else {
								MessageBox.error(error.responseText);
							}
						}.bind(this)
					});
				}
			},

			_deleteQuotations: function () {
				let sPath = "/ETS_QTN_ITEMSet",
					aFilter = [];

				aFilter.push(
					new Filter({
						filters: [
							new Filter("DELETE_FLAG", FilterOperator.EQ, "X"),
						],
					})
				);
				var mParameters = {
					filters: aFilter
				}
				this.getView().getModel("customer.quotations").read(sPath, mParameters);

				let oChangeData = this.getView().getModel("changeItemModel").getData();
				oChangeData.material = "";
				oChangeData.plant = "";
				oChangeData.condType = "";
				oChangeData.price = "";
				oChangeData.currency = "";
				oChangeData.quantity = "";
				oChangeData.unit = "";
				oChangeData.volume = "";
				oChangeData.volUnit = "";
				this.getView().getModel("changeItemModel").setData(oChangeData);
			},

			onItemCancel: function () {
				var oData = this.getView().getModel("localIconModel").getData();
				oData.check = true;
				oData.materialIcon = false;
				oData.quantityIcon = false;
				this.getView().getModel("localIconModel").setData(oData);

				// navigating back
				window.history.go(-1);

				// need to refresh input entries
				let oChangeData = this.getView().getModel("changeItemModel").getData();
				oChangeData.material = "";
				oChangeData.plant = "";
				oChangeData.condType = "";
				oChangeData.price = "";
				oChangeData.currency = "";
				oChangeData.quantity = "";
				oChangeData.unit = "";
				oChangeData.volume = "";
				oChangeData.volUnit = "";
				this.getView().getModel("changeItemModel").setData(oChangeData);

				let oform = this.getView().byId(this.getView().getId() + "--customer.zsdsqmccs1.v2._IDGroupItem1")
				oform.getFormElements().forEach((element, idx) => {
					if (idx !== 4) {
						let aItems = element.getFormElement().getFields()[0].getItems();
						aItems[3].getItems()[0].setVisible(true);
						aItems[3].getItems()[1].setVisible(false);
						aItems[6].getItems()[0].setVisible(false);
						aItems[6].getItems()[1].setVisible(false);
					}
				});

				let oChangeModel = this.getView().getModel("localModel").getData();

				oChangeModel.basicData.plant.currentOperation = "";
				oChangeModel.basicData.material.currentOperation = "";
				oChangeModel.basicData.price.currentOperation = "";
				oChangeModel.basicData.quantity.currentOperation = "";
				oChangeModel.basicData.volume.currentOperation = "";

				this.getView().getModel("localModel").setData(oChangeModel);

			},

			_processData: function (data) {
				let oIconData = this.getView().getModel("localIconModel").getData();
				let material = [], quantity = [];
				data.forEach(element => {
					if (!material.includes(element.MATNR)) {
						material.push(element.MATNR);
					}
				});

				data.forEach(element => {
					if (!quantity.includes(element.KWMENG)) {
						quantity.push(element.KWMENG);
					}
				});

				if (material.length > 1) {
					oIconData.materialIcon = true;
				}

				if (quantity.length > 1) {
					oIconData.quantityIcon = true;
				}

				this.getView().getModel("localIconModel").setData(oIconData);

				this.getView().getModel("localModel").setProperty("/Quotations", data);
			},

			onPlantChange: function (oEvt) {
				oEvt;
			}
		});
	});